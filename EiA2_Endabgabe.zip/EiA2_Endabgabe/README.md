L01_Zufallsgedicht: https://feloffel.github.io/EiA2_SoSe24/L01_Zufallsgedicht <br>
L02_Event-Inspector: <link>https://feloffel.github.io/EiA2_SoSe24/L02_Event-Inspector</link> <br>
L03_Einkaufsliste: <link>https://feloffel.github.io/EiA2_SoSe24/L03_Einkaufsliste</link> <br>
L04_Einkaufsliste: <link>https://feloffel.github.io/EiA2_SoSe24/L04_Einkaufsliste</link> <br>
L08.1_Generative Kunst: <link>https://feloffel.github.io/EiA2_SoSe24/L08.1_GenerativeKunst</link> <br>
L09_EntenteichClasses: <link>https://feloffel.github.io/EiA2_SoSe24/L09_EntenteichClasses</link> <br>
L10_inheritance: https://feloffel.github.io/EiA2_SoSe24/L10_Inheritance <br>
L10_inheritance: https://feloffel.github.io/EiA2_SoSe24/L10_Inheritance_Polymorph <br>
L11_Advanced: https://feloffel.github.io/EiA2_SoSe24/L11_Advanced <br>
L12_Addition: https://feloffel.github.io/EiA2_SoSe24/L12_Addition
