"use strict";
var EisDealer;
(function (EisDealer) {
    class Drawable {
    }
    EisDealer.Drawable = Drawable;
})(EisDealer || (EisDealer = {}));
//# sourceMappingURL=Drawable.js.map